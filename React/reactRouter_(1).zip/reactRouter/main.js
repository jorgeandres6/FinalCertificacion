import React from 'react';
import { render } from 'react-dom';
import { Router, Route, browserHistory } from 'react-router';
import App from './App.jsx';
import Home from './Home.jsx';
import Usuarios from './Usuarios.jsx';
import Lenguajes from './Lenguajes.jsx';

render(
    <Router history={browserHistory}>
        <Route path="/" component={App} />
        <Route path="/home" component={Home} />
        <Route path="/usuarios" component={Usuarios} />
        <Route path="/lenguajes" component={Lenguajes} />
    </Router>,
    document.getElementById('app')
);
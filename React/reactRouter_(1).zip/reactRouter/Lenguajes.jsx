import React from 'react';

class Lenguajes extends React.Component {
    render() {
        return (
            <div>
                <h2>Lenguajes de Programación</h2>
            </div>
        );
    }
}

export default Lenguajes;
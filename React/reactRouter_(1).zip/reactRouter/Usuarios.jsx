import React from 'react';

class Usuarios extends React.Component {
    render() {
        return (
            <div>
                <h2>Usuarios de la Aplicación</h2>
            </div>
        );
    }
}

export default Usuarios;